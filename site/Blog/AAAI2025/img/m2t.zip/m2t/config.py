class Config:
    BATCH_SIZE = 32
    NUM_EPOCHS = 10
    LEARNING_RATE = 1e-4
    DEVICE = "cuda"
    GPUS = [0, 1, 2, 3]
    MODEL_PATH = "./flan-t5-base"  # or "t5-base"
    TOKENIZER_PATH = "./flan-t5-base"  # or "t5-base"
    DATA_DIR = "./data/"
    OUTPUT_DIR = "./output/"